Emmanuel Cabili Cuyugan
387094
05/02/2024


In Partial Fulfilment of The University of Law’s:
MSc - Computer Science - Web Technologies - Online FT - Sep 23 Start - October 2023
Assessment 1: Coursework Portfolio


Personal Portfolio README:
ACCESS @ https://github.com/emmcygn/MSCWTPortfolio-Site


Intro: This website is built primarily to provide a platform for potential recruiters to learn about me and to showcase my development experience by creating a cohesive, concise, and engaging portfolio website that also demonstrates my web technology capabilities. Built using a mixture of custom HTML written by myself and by using powerful CSS and Javascript libraries on Elementor/Wordpress, I was able to create a site that I am proud of showcasing. 

How to run: Open the index.html file within the downloaded folder to load the page.


Troubleshooting: Can’t open file? Check if browser allows for opening of external links


Notes and Future Development Plans


Building this portfolio site was a good practice in working hand in hand with powerful web builders and libraries and to be able to use powerful “templates” to guide the webpage development proces.

Moving forward, I intend to use the modular gallery section to add my upcoming projects, add more scripting to the elements, and to create a separate projects page with a full breakdown of each project.